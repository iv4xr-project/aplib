/**
 * Some experiments for the TPJ paper.
 */
package eu.iv4xr.framework.exampleTestAgentUsage.miniDungeon.TPJ;