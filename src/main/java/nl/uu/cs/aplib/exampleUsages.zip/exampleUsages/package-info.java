/**
 * Providing several examples of the usage of aplib agents.
 */
package nl.uu.cs.aplib.exampleUsages;