/**
 * Five-game is a simple board game.
 * 
 * For a demo of the game: run the main of {@link FiveGame}.
 * 
 * For a demo of aplib agent playing the game: run the main of 
 * {@link FiveGame_withAgent}.
 */
package nl.uu.cs.aplib.exampleUsages.fiveGame;